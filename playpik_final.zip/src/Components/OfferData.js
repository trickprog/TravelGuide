const Offerdata = [
    {
        id: 1,
        title: 'Exclusive For New Customer',
        price: 40,
        type: 'Upto',
        img: '1',
        discription: 'lorem asdsan doiunas du nsau ndsiaund iusna diunnuenaunw auin a  afn',
    },
    {
        id: 2,
        title: 'Exclusive For New Customer',
        price: 40,
        type: 'Upto',
        img: '1',
        discription: 'lorem asdsan doiunas du nsau ndsiaund iusna diunnuenaunw auin a  afn',
    },
    {
        id: 3,
        title: 'Exclusive For New Customer',
        price: 40,
        type: 'Upto',
        img: '1',
        discription: 'lorem asdsan doiunas du nsau ndsiaund iusna diunnuenaunw auin a  afn',
    },
    
]

export default Offerdata